git add .
git commit -m "new commit"
git push -f

